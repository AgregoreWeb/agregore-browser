# extension-agregore-history
Agregore's history tracking web extension. History is stored inside a 
