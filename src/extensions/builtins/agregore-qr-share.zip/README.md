# extension-agregore-qr-share
Visit and Share QR codes with the Agregore Browser

## How it works:

- Adds a browser action to open the QR Share page
- Generates a QR Code for your most recently active window
- Click the "scan" button to begin scanning for QR codes using your camera
- Once a QR code is seen, a new window will be opened for the URL
- Remember to close the scan popup when you're done

